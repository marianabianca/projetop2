package exception;

@SuppressWarnings("serial")
public class LogicaException extends Exception {
	
	public LogicaException(String msg) {
		super(msg);
	}

}
