package exception;

@SuppressWarnings("serial")
public class ObjetoNuloException extends Exception {
	public ObjetoNuloException(String msg) {
		super(msg);
	}
}
