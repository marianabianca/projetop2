package exception;

@SuppressWarnings("serial")
public class ParametroInvalidoException extends LogicaException {
	
	public ParametroInvalidoException(String msg) {
		super(msg);
	}
}
