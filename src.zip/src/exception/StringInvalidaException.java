package exception;

@SuppressWarnings("serial")
public class StringInvalidaException extends Exception {

	public StringInvalidaException(String msg) {
		super(msg);
	}

}
